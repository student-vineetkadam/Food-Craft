<?php
$showalert = false;
$showerror = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Include database connection
    include 'partials/db_connect.php';

    // Collect input data
    $username = $_POST["username"];
    $password = $_POST["password"];
    $cpassword = $_POST["cpassword"];

    // Check if passwords match
    if ($password == $cpassword) {
        // Insert data into the database
        $sql = "INSERT INTO `users` (`username`, `password`, `dt`) VALUES ('$username', '$password', current_timestamp())";
        $result = mysqli_query($conn, $sql);

        if ($result) {
            $showalert = true; // Successful registration
        } else {
            $showerror = "Error inserting data: " . mysqli_error($conn); // Database error
        }
    } else {
        $showerror = "Passwords do not match!";
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
            /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: #f7f7f7;
    color: #333;
    display: flex;
    flex-direction: column;
    min-height: 100vh;
}
/* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: 'Poppins', sans-serif;
    background-color: #f7f7f7;
    color: #333;
}

/* Navbar Styles */
.navbar {
    background-color: #ffffff;
    border-bottom: 2px solid #4CAF50;
    width: 100%;
    padding: 10px 0;
    position: sticky;
    top: 0;
    z-index: 10;
}

.navbar .container {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0 20px;
}

.logo-container h1 {
    font-size: 1.8rem;
    color: #4CAF50;
    font-weight: bold;
    text-decoration: none;
}

.nav-menu {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-menu li {
    position: relative;
}

.nav-menu a {
    text-decoration: none;
    color: #4CAF50;
    font-weight: 600;
    font-size: 1rem;
    transition: color 0.3s ease;
}

.nav-menu a:hover {
    color: #333;
}

/* Dropdown Styles */
.dropdown {
    position: relative;
}

.dropdown-content {
    display: none;
    position: absolute;
    background-color: #ffffff;
    box-shadow: 0px 8px 16px rgba(0, 0, 0, 0.2);
    border: 1px solid #4CAF50;
    padding: 10px;
    z-index: 1;
    min-width: 150px;
}

.dropdown:hover .dropdown-content {
    display: block;
}

.dropdown-content a {
    color: #333;
    padding: 8px 16px;
    text-decoration: none;
    display: block;
    font-size: 0.9rem;
}

.dropdown-content a:hover {
    background-color: #f1f1f1;
    color: #4CAF50;
}


/* Signup Form Container */
.signup-container {
    margin-top: 50px;
    padding: 40px;
    background: linear-gradient(90deg, #54880e, #f2f2f2);
    border-radius: 20px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    width: 500px;
    max-width: 90%;
    text-align: center;
}

.signup-container h1 {
    font-size: 2rem;
    color: #4CAF50;
    margin-bottom: 20px;
}

.signup-container .form-group label {
    font-weight: bold;
    color: #333;
}

.signup-container .form-control {
    border: 2px solid #4CAF50;
    border-radius: 10px;
    padding: 10px;
}

.signup-container .form-control:focus {
    border-color: #54880e;
    box-shadow: 0 0 5px rgba(84, 136, 14, 0.5);
}

.signup-container .btn {
    background-color: #4CAF50;
    color: #fff;
    border: none;
    border-radius: 10px;
    padding: 10px 20px;
    font-size: 1rem;
    cursor: pointer;
}

.signup-container .btn:hover {
    background-color: #54880e;
}

/* Footer Styles */
footer {
    background-color: #ffffff;
    border-top: 2px solid #4CAF50;
    text-align: center;
    padding: 15px 0;
    width: 100%;
    margin-top: auto;
}

footer p {
    color: #333;
    font-size: 1rem;
}

        
    </style>
    <title>Signup</title>
</head>

<body>
    <!-- Navbar -->
    <nav class="navbar">
        <div class="container">
            <div class="logo-container">
                <h1>Food Craft</h1> 
            </div>
            <ul class="nav-menu">
                <li><a href="home.html">Home</a></li>
                <li><a href="login.php">Login</a></li>
                <li><a href="signup.php">Signup</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <!-- Alerts for success/error -->
    <?php
    if ($showalert) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> Your account is now created and you can login now.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    if ($showerror) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> ' . $showerror . '.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    ?>

    <!-- Signup Form -->
    <div class="container signup-container">
        <h1 class="text-center">Register</h1>
        <form action="signup.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
            </div>
            <div class="form-group">
                <label for="cpassword">Confirm Password</label>
                <input type="password" class="form-control" id="cpassword" name="cpassword" placeholder="Confirm Password">
                <small id="passwordHelp" class="form-text text-muted">Make sure to type the same password.</small>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; 2024 food craft | All Rights Reserved</p>
    </footer>

    <!-- JavaScript links -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>
     