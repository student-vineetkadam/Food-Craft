// feedback.js

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('feedback-form').addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent the form from submitting the traditional way

        const name = document.getElementById('name').value;
        const email = document.getElementById('email').value;
        const message = document.getElementById('message').value;

        // Perform feedback submission logic here (e.g., sending data to a server)

        // Display a thank you message
        document.getElementById('feedback-response').textContent = 'Thank you for your feedback!';
        
        // Optionally, you can clear the form
        document.getElementById('feedback-form').reset();
    });
});
