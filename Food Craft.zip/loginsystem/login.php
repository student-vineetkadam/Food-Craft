<?php

$login = false;
$showerror = false;

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    include 'partials/db_connect.php';

    // Sanitize inputs
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);

    // SQL query
    $sql = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        $num = mysqli_num_rows($result);

        if ($num == 1) {
            // Start session and set variables
            session_start();
            $_SESSION['loggedin'] = true;
            $_SESSION['username'] = $username;

            // Redirect to welcome page
            header("Location: welcome.php");
            exit(); // Ensure script stops execution after redirection
        } else {
            $showerror = "Invalid Credentials!";
        }
    } else {
        $showerror = "Error: " . mysqli_error($conn);
    }
}

?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css">
    <style>
        /* General Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f7f7f7;
            color: #333;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* Navbar Styles */
        .navbar {
            background-color: #ffffff;
            border-bottom: 2px solid #4CAF50;
            width: 100%;
            padding: 10px 0;
            position: sticky;
            top: 0;
            z-index: 10;
        }

        .navbar .container {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .logo-container h1 {
            font-size: 1.8rem;
            color: #4CAF50;
            font-weight: bold;
            text-decoration: none;
        }

        .nav-menu {
            list-style: none;
            display: flex;
            gap: 20px;
        }

        .nav-menu a {
            text-decoration: none;
            color: #4CAF50;
            font-weight: 600;
            font-size: 1rem;
            transition: color 0.3s ease;
        }

        .nav-menu a:hover {
            color: #333;
        }

        /* Login Form Container */
        .login-container {
            margin-top: 50px;
            padding: 40px;
            background: linear-gradient(90deg, #54880e, #f2f2f2);
            border-radius: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            width: 500px;
            max-width: 90%;
            text-align: center;
        }

        .login-container h1 {
            font-size: 2rem;
            color: #4CAF50;
            margin-bottom: 20px;
        }

        .login-container .form-group label {
            font-weight: bold;
            color: #333;
        }

        .login-container .form-control {
            border: 2px solid #4CAF50;
            border-radius: 10px;
            padding: 10px;
        }

        .login-container .form-control:focus {
            border-color: #54880e;
            box-shadow: 0 0 5px rgba(84, 136, 14, 0.5);
        }

        .login-container .btn {
            background-color: #4CAF50;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 10px 20px;
            font-size: 1rem;
            cursor: pointer;
        }

        .login-container .btn:hover {
            background-color: #54880e;
        }

        /* Footer Styles */
        footer {
            background-color: #ffffff;
            border-top: 2px solid #4CAF50;
            text-align: center;
            padding: 15px 0;
            width: 100%;
            margin-top: auto;
        }

        footer p {
            color: #333;
            font-size: 1rem;
        }
    </style>
    <title>Login</title>
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo-container">
                <h1>Food Craft</h1>
            </div>
            <ul class="nav-menu">
                <li><a href="home.html">Home</a></li>
                <li><a href="/loginsystem/login.php">Login</a></li>
                <li><a href="/loginsystem/signup.php">Signup</a></li>
                <li><a href="/loginsystem/logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <?php
    if ($login) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <strong>Success!</strong> You are logged in.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    if ($showerror) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <strong>Error!</strong> ' . $showerror . '.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
              </div>';
    }
    ?>

    <div class="container login-container">
        <h1 class="text-center">Login</h1>
        <form action="/loginsystem/login.php" method="post">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter username">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" placeholder="Enter password">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2024 Food Craft | All Rights Reserved</p>
    </footer>

    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/js/bootstrap.min.js"></script>
</body>

</html>
