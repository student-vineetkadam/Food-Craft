<?php
session_start();

if(!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] != true){
    header("location :login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FoodCraft <?php echo htmlspecialchars($_SESSION['username']); ?></title>
    <style>
    /* General Styles */
body {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    color: #333;
}

.container {
    width: 80%;
    margin: 0 auto;
}

/* Header */
header {
    background-color: #ffffff;
    border-bottom: 2px solid #4CAF50;
    padding: 20px 0;
}

header .container {
    display: flex;
    flex-direction: column;
    align-items: center;
}

header .logo-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 10px;
}

header .logo {
    height: 80px; /* Increased logo size */
    margin-bottom: 10px;
}

header .logo-container h1 {
    margin: 0;
    font-size: 3rem; /* Increased font size */
    color: #4CAF50;
}

header nav {
    width: 100%;
}

header nav .nav-menu {
    list-style: none;
    padding: 0;
    display: flex;
    justify-content: center;
    margin: 0;
    background-color: #f1f1f1;
    border-radius: 8px;
}

header nav .nav-menu li {
    position: relative;
    margin: 0;
}

header nav .nav-menu a {
    color: #4CAF50;
    text-decoration: none;
    font-size: 1.2rem;
    padding: 12px 20px;
    display: block;
    transition: background-color 0.3s ease, color 0.3s ease;
}

header nav .nav-menu a:hover {
    background-color: #4CAF50;
    color: #ffffff;
    border-radius: 5px;
}

header nav .nav-menu .dropdown-content {
    display: none;
    position: absolute;
    top: 100%;
    left: 0;
    background-color: #ffffff;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    z-index: 1;
}

header nav .nav-menu .dropdown-content a {
    color: #333;
    padding: 12px 20px;
    white-space: nowrap;
}

header nav .nav-menu .dropdown-content a:hover {
    background-color: #f1f1f1;
}

header nav .nav-menu .dropdown:hover .dropdown-content {
    display: block;
}

/* Hero Section */
#hero {
    background-color: #e8f5e9;
    padding: 60px 20px;
    text-align: center;
}

#hero h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
}

#hero p {
    font-size: 1.2rem;
    margin-bottom: 30px;
}

#hero .btn {
    background-color: #4CAF50;
    color: white;
    padding: 15px 30px;
    text-decoration: none;
    font-size: 1.2rem;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

#hero .btn:hover {
    background-color: #388E3C;
}

/* Goals Section */
#goals {
    background-color: #f1f1f1;
    padding: 60px 20px;
    text-align: center;
}

#goals h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
}

#goals p {
    font-size: 1.2rem;
    color: #555;
}

/* Customer Reviews Section */
#reviews {
    padding: 60px 20px;
    text-align: center;
}

#reviews h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
}

.review {
    background-color: #fff;
    border: 1px solid #ddd;
    border-radius: 8px;
    margin: 20px auto;
    padding: 20px;
    max-width: 600px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.review p {
    font-size: 1.2rem;
    margin: 0;
}

.review strong {
    display: block;
    margin-top: 10px;
}

/* Founders Section */
#founders {
    background-color: #e8f5e9;
    padding: 60px 20px;
    text-align: center;
}

#founders h2 {
    font-size: 2.5rem;
    margin-bottom: 20px;
}

#founders p {
    font-size: 1.2rem;
    color: #555;
}

#founders ul {
    list-style: none;
    padding: 0;
}

#founders ul li {
    font-size: 1.2rem;
    margin: 10px 0;
}

/* Footer */
footer {
    background-color: #4CAF50;
    padding: 20px 0;
    text-align: center;
    color: white;
}

footer p {
    margin: 0;
    font-size: 1rem;
}

#feedback-section {
    padding: 20px;
    background-color: #f9f9f9;
    border-top: 2px solid #ddd;
    margin-top: 30px;
}

#feedback-section h2 {
    margin-bottom: 15px;
}

#feedback-section form {
    display: flex;
    flex-direction: column;
}

#feedback-section label {
    margin: 5px 0;
}

#feedback-section input, #feedback-section textarea {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

#feedback-section button {
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

#feedback-section button:hover {
    background-color: #0056b3;
}

#feedback-response {
    margin-top: 10px;
    color: green;
}


   </style>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
</head>
<body>

    <header>
        <div class="container">
            <div class="logo-container">
                
                <h1>FoodCraft</h1> 
            </div>
            <nav>
    <ul class="nav-menu">
        <li><a href="home.html">Home</a></li>
        <li><a href="top10.html">Top Recipes</a></li>
        <li class="dropdown">
            <a>About Us</a>
            <div class="dropdown-content">
                <a href="goals.html">Our Goals</a>
                <a href="founders.html">Founders</a>
            </div>
        </li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

    </header>

    <section id="hero">
        <div class="container">
            <h2>Welcome to FoodCraft</h2>
            <p>Your go-to destination for calorie-based meal planning and recipe suggestions. Discover delicious recipes tailored to your calorie needs!</p>
            <a href="find,getstarted.html" class="btn">Find Recipes</a>
        </div>
    </section>

    <section id="goals">
        <div class="container">
            <h2>Our Goals</h2>
            <p>At FoodCraft, our mission is to provide personalized meal suggestions that cater to your calorie requirements while promoting healthy and enjoyable eating habits. We aim to simplify meal planning by offering recipes that fit your nutritional needs and preferences.</p>
        </div>
    </section>

    <section id="reviews">
        <div class="container">
            <h2>What Our Users Say</h2>
            <div class="review">
                <p>"FoodCraft has completely transformed the way I plan my meals. The calorie-based recommendations are spot on and have helped me stay on track with my fitness goals!"</p>
                <p><strong>- jatin </strong></p>
            </div>
            <div class="review">
                <p>"I love how easy it is to find recipes that fit my calorie requirements. The website is user-friendly and the recipes are delicious!"</p>
                <p><strong>- prakhar </strong></p>
            </div>
            <div class="review">
                <p>"FoodCraft offers a fantastic range of recipes. It's great to have options that are both healthy and tailored to my dietary needs."</p>
                <p><strong>- ved </strong></p>
            </div>
        </div>
    </section>

 
    <section id="founders">
        <div class="container">
            <h2>Meet the Founders</h2>
            <p>FoodCraft is a project created by four dedicated BSc Computer Science students. We are passionate about technology and healthy eating, and this project is a testament to our commitment to combining the two. Learn more about us:</p>
            <ul>
                <li><strong>Aarya Jadhav</strong> - Aarya is focused on front-end development and user experience design.</li>
                <li><strong>Keshav Sinha</strong> - Keshav specializes in back-end development and database management.</li>
                <li><strong>Rohin Thakur</strong> - Rohin handles project management and system integration.</li>
                <li><strong>Vineet Kadam</strong> - Vineet is responsible for UI/UX design and overall site aesthetics.</li>
            </ul>
            <p>We are in our 3rd year of BSc Computer Science and this project represents our efforts to apply our knowledge in a practical and impactful way.</p>
        </div>
    </section>

   <!-- Your existing HTML code -->

<!-- Feedback Section -->
<section id="feedback-section">
    <h2>We'd Love Your Feedback!</h2>
    <form id="feedback-form">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="message">Message:</label>
        <textarea id="message" name="message" rows="4" required></textarea>

        <button type="submit">Submit Feedback</button>
    </form>
    <p id="feedback-response"></p>
</section>
</body>
</html>


   
    <footer>
        <div class="container">
            <p>&copy; 2024 FoodCraft. All Rights Reserved.</p>
        </div>
    </footer>

</body>
</html>
